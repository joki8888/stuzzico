//packages
var express 	   = require("express");
var app 		   = express();
var bodyParser     = require("body-parser");
var mysql 		   = require('mysql');
var express 	   = require('express');
var credentials    = require('./pass_conf.js').pass();
var multer         = require('multer');
var path  		   = require('path');
var cors		   = require('cors');
//some tools
app.use(cors());
app.use(bodyParser.json());
// CORS middleware
const allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', '*');
    res.header('Access-Control-Allow-Headers', '*');
    next();
}
app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");

var con = mysql.createConnection({
  host: "localhost",
  port: 3306,
  database: 'shop',
  user: 'root'
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

//css 
app.use(express.static('public'));


//uploading to the my PC
app.use('/static', express.static('public'));

var storage        = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'C:/Users/Джавохир/Stuzzico/public/uploads')
  },
  filename: function (req, file, cb) {
     cb(null, Date.now() + path.extname(file.originalname))
  }
});

var upload = multer({ storage: storage });

//the main route
app.get("/", function(req,res){
	res.redirect("main");
});

app.get("/main", function(req,res){

//take items frmon BD
var sql1 = "SELECT * FROM goods WHERE category = 'pizza' ";	
var sql2 = "SELECT * FROM goods WHERE category = 'soup' ";
var sql3 = "SELECT * FROM goods WHERE category = 'pasta' ";
var sql4 = "SELECT * FROM goods WHERE category = 'hotdishes' ";
var sql5 = "SELECT * FROM goods WHERE category = 'salat' ";
var sql6 = "SELECT * FROM goods WHERE category = 'appetisers' ";
var sql7 = "SELECT * FROM goods WHERE category = 'sidedishes' ";
var sql8 = "SELECT * FROM goods WHERE category = 'childrensmenu' ";

con.query(sql1, function (err, result1) {
if (err) throw err;

	con.query(sql2, function (err, result2) {
	if (err) throw err;

		con.query(sql3, function (err, result3) {
		if (err) throw err;

			con.query(sql4, function (err, result4) {
			if (err) throw err;

				con.query(sql5, function (err, result5) {
				if (err) throw err;

					con.query(sql6, function (err, result6) {
					if (err) throw err;

						con.query(sql7, function (err, result7) {
						if (err) throw err;

							con.query(sql8, function (err, result8) {
							if (err) throw err;

									res.render("main", {pizza: result1, soup: result2, pasta: result3, hotdishes: result4, salat: result5, appetisers: result6, sidedishes: result7, childrensmenu: result8});

								});
							});	
						});
					});
				});
			});
		});
	});
});

//put into the main shop
app.post("/main",  upload.single('image'), function(req, res, next){
	var name = req.body.name;
	var image = req.file.filename;
	var description = req.body.description;
	var price = req.body.price;
	var category = req.body.category;
	var item = [
		[name, price, description, image, category]
	];
	var sql = "INSERT INTO goods (name, price, description, image, category) VALUES ?";

	con.query(sql, [item], function (err, result) {
	    if (err) throw err;
	    console.log("Number of records inserted: " + result.affectedRows);
	 });
	res.redirect("/main");
});

//admin
app.get('/main/new', function(req, res){
	res.redirect('/admin');
});

app.get("/admin", function(req, res){
	res.render("admin.ejs");
});

app.post("/admin", function(req, res){
	var username = req.body.username;
	var password = req.body.password;
	if(username == credentials.login && password == credentials.pass){
		res.redirect("/main/new/"+username+password);
	} else {
		res.render('admin.ejs', {msg: 'error'});
	}

});

//shop

app.get("/shop", function(req, res){

var sql1 = "SELECT * FROM goods WHERE category = 'pizza' ";	
var sql2 = "SELECT * FROM goods WHERE category = 'soup' ";
var sql3 = "SELECT * FROM goods WHERE category = 'pasta' ";
var sql4 = "SELECT * FROM goods WHERE category = 'hotdishes' ";
var sql5 = "SELECT * FROM goods WHERE category = 'salat' ";
var sql6 = "SELECT * FROM goods WHERE category = 'appetisers' ";
var sql7 = "SELECT * FROM goods WHERE category = 'sidedishes' ";
var sql8 = "SELECT * FROM goods WHERE category = 'childrensmenu' ";

con.query(sql1, function (err, result1) {
if (err) throw err;

	con.query(sql2, function (err, result2) {
	if (err) throw err;

		con.query(sql3, function (err, result3) {
		if (err) throw err;

			con.query(sql4, function (err, result4) {
			if (err) throw err;

				con.query(sql5, function (err, result5) {
				if (err) throw err;

					con.query(sql6, function (err, result6) {
					if (err) throw err;

						con.query(sql7, function (err, result7) {
						if (err) throw err;

							con.query(sql8, function (err, result8) {
							if (err) throw err;

									res.render("shop.ejs", {pizza: result1, soup: result2, pasta: result3, hotdishes: result4, salat: result5, appetisers: result6, sidedishes: result7, childrensmenu: result8});

								});
							});	
						});
					});
				});
			});
		});
	});
});

app.get("/main/new/adminadmin", function(req,res){

//take items frmon BD
var sql1 = "SELECT * FROM customers";	
var sql2 = "SELECT * FROM ordered_items";	
var sql3 = "SELECT * FROM goods";

con.query(sql1, function (err, res1) {
	if (err) throw err;

		con.query(sql2, function (err, res2) {
			if (err) throw err;
				var customers = JSON.parse(JSON.stringify(res1));

				customers.map(function(item){
				 	item.order = [];
				 		res2.map(function(res2){
					 		if(res2.order_id == item.id){
					 				var good = JSON.parse(JSON.stringify(res2));
						 			item.order.push(good);
					 		}
				 		});
				})
				 		console.log(customers[0].order);
				res.render("new.ejs", {items: JSON.parse(JSON.stringify(customers))});
				});
		});
});	

app.post('/neworder', function(req, res){
	var name = req.body.name;
	var phone = req.body.phone;
	var address = req.body.address;
	var order = req.body.order;
	var totalprice = req.body.totalprice;
	var item = [
		[name, phone, address, totalprice]
	];
	var sql = "INSERT INTO customers (name, phone, address, totalprice) VALUES ?";

	con.query(sql, [item], function (err, result) {
	    if (err) throw err;
    	console.log("Number of records inserted: " + result.affectedRows);
    	console.log(result.insertId);
    	var order_id = result.insertId;
		var sql1 = "INSERT INTO ordered_items (good_id, order_id, quantity, good_name) VALUES ?";

		for(var i=0;i<order.length;i++){
			var items = [
				[order[i].id, result.insertId, order[i].q, req.body.order[i].name]
			];
			con.query(sql1, [items], function(err, result){
				if(err) throw err;
				console.log("Yes");
			})
		}

	 });

console.log(req.body);
res.send({msg: '200 OK'});
})
//listener
app.listen(2000, function(){
	console.log("The Server has started!");
});