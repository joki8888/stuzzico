exports.pass = function()
	{
		return {
			pass: 'admin',
			login: 'admin'	
		}
		
}
	
